# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hemul']

package_data = \
{'': ['*']}

install_requires = \
['ipython>=8.5.0,<9.0.0', 'jupyter>=1.0.0,<2.0.0', 'numpy>=1.23.4,<2.0.0']

setup_kwargs = {
    'name': 'hemul',
    'version': '0.1.0',
    'description': 'FHE simulator',
    'long_description': None,
    'author': 'Hoseung Choi',
    'author_email': 'hschoi@dinsight.ai',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}
from build11 import *
build(setup_kwargs)

setup(**setup_kwargs)
